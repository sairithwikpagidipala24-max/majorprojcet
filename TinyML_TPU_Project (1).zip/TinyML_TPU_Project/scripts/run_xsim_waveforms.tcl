log_wave -r /tpu_top_tb/*
run 500 ns
quit
