import random


def compute_reference(a, b, active_rows_mask=0b1111, active_cols_mask=0b1111):
    output = []
    for i in range(len(a)):
        if (active_rows_mask >> i) & 1:
            col_sum = sum(b[j] for j in range(len(b)) if (active_cols_mask >> j) & 1)
            output.append(a[i] * col_sum)
        else:
            output.append(0)
    return output


def compute_reference_explicit(a, b, active_rows_mask=0b1111, active_cols_mask=0b1111):
    output = []
    for i in range(len(a)):
        if (active_rows_mask >> i) & 1:
            row_total = 0
            for j in range(len(b)):
                if (active_cols_mask >> j) & 1:
                    row_total += a[i] * b[j]
            output.append(row_total)
        else:
            output.append(0)
    return output


def simulate_case(name, a, b, expected=None, precision_mode='INT8', active_rows_mask=0b1111, active_cols_mask=0b1111):
    reference = compute_reference(a, b, active_rows_mask, active_cols_mask)
    print(f'Case: {name}')
    print(f'Precision mode: {precision_mode}')
    print(f'A vector: {a}')
    print(f'B vector: {b}')
    print(f'Active rows: {active_rows_mask:#06b}')
    print(f'Active cols: {active_cols_mask:#06b}')
    print(f'Reference row outputs: {reference}')

    if expected is not None:
        ok = (reference == expected)
        print(f'Expected: {expected} -> {"PASS" if ok else "FAIL"}')
        return ok
    return True


def generate_random_workload(size=4, low=-5, high=5):
    return [random.randint(low, high) for _ in range(size)]


def run_mask_sweep():
    test_vectors = [
        ([-2, 3, -1, 4], [5, -6, 7, -8]),
        ([2, 3, 1, 4], [5, 6, 7, 8]),
        ([0, -3, 2, 4], [1, 0, -2, 5]),
        ([1, 1, 1, 1], [1, 1, 1, 1]),
    ]

    for a, b in test_vectors:
        for row_mask in range(1 << len(a)):
            for col_mask in range(1 << len(b)):
                expected = compute_reference_explicit(a, b, row_mask, col_mask)
                actual = compute_reference(a, b, row_mask, col_mask)
                if expected != actual:
                    print(f'EXHAUSTIVE MASK CHECK FAIL: a={a}, b={b}, row_mask={row_mask:#06b}, col_mask={col_mask:#06b}')
                    print(f'Expected {expected}, got {actual}')
                    return False
    print('Exhaustive mask sweep: PASS')
    return True


def run_reference_suite():
    cases = [
        ('unsigned_partial_mask', [2, 3, 1, 4], [5, 6, 7, 8], [0, 0, 11, 44], 'INT8', 0b1100, 0b0011),
        ('unsigned_full_mask', [2, 3, 1, 4], [5, 6, 7, 8], [52, 78, 26, 104], 'INT8', 0b1111, 0b1111),
        ('signed_full_mask', [-2, 3, -1, 4], [5, -6, 7, -8], [4, -6, 2, -8], 'INT8', 0b1111, 0b1111),
        ('random_small', generate_random_workload(4), generate_random_workload(4), None, 'MIXED', 0b1111, 0b1111),
    ]

    all_pass = True
    for name, a, b, expected, mode, active_rows_mask, active_cols_mask in cases:
        ok = simulate_case(name, a, b, expected, mode, active_rows_mask, active_cols_mask)
        print('-' * 40)
        all_pass = all_pass and ok

    all_pass = all_pass and run_mask_sweep()
    print(f'OVERALL: {"PASS" if all_pass else "FAIL"}')
    return all_pass


if __name__ == '__main__':
    ok = run_reference_suite()
    raise SystemExit(0 if ok else 1)
