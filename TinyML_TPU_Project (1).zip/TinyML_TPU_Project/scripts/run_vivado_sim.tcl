set script_dir [file dirname [file normalize [info script]]]
set repo_root [file normalize [file join $script_dir ..]]
set rtl_dir [file join $repo_root "rtl"]
set tb_dir [file join $repo_root "tb"]
set project_root [file join $repo_root "vivado_sim"]

file mkdir $project_root

create_project -force tinyml_tpu_vivado $project_root -part xc7a35tcpg236-1
set_property target_language Verilog [current_project]
set_property simulator_language Verilog [current_project]

add_files -norecurse [glob -directory $rtl_dir *.sv]
add_files -norecurse [glob -directory $tb_dir *.sv]

# Keep the testbench as the top-level simulation entry point.
set_property top tpu_top_tb [get_filesets sim_1]
update_compile_order -fileset sources_1
update_compile_order -fileset sim_1

launch_simulation -simset sim_1 -mode behavioral -scripts_only

set sim_dir [file join $project_root "tinyml_tpu_vivado.sim" "sim_1" "behav" "xsim"]
set previous_dir [pwd]
cd $sim_dir
if {[catch {
	exec cmd /c compile.bat
	exec cmd /c elaborate.bat
	exec xsim tpu_top_tb_behav -tclbatch [file join $script_dir "run_xsim_waveforms.tcl"] -log simulate_waveforms.log
} sim_output]} {
	cd $previous_dir
	close_project
	error $sim_output
}
puts $sim_output
cd $previous_dir

close_project
