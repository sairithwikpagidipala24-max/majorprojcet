$rtlFiles = Get-ChildItem -Path "$PSScriptRoot\..\rtl" -Filter *.sv | Select-Object -ExpandProperty FullName
$tbFiles = Get-ChildItem -Path "$PSScriptRoot\..\tb" -Filter *.sv | Select-Object -ExpandProperty FullName

$iverilogCandidates = @(
    'iverilog.exe',
    'C:\iverilog\bin\iverilog.exe',
    "$env:ProgramFiles\Icarus Verilog\bin\iverilog.exe",
    "$env:ProgramFiles(x86)\Icarus Verilog\bin\iverilog.exe"
)

$iverilogPath = $null
foreach ($candidate in $iverilogCandidates) {
    if ($candidate -and (Test-Path $candidate)) {
        $iverilogPath = $candidate
        break
    }
}

if (-not $iverilogPath) {
    $env:PATH += ';C:\iverilog\bin'
    $iverilogCmd = Get-Command iverilog -ErrorAction SilentlyContinue
    if ($iverilogCmd) {
        $iverilogPath = $iverilogCmd.Source
    }
}

if (-not $iverilogPath) {
    Write-Error "iverilog.exe was not found. Install Icarus Verilog or add C:\iverilog\bin to PATH."
    exit 1
}

$vvpPath = $iverilogPath -replace 'iverilog\.exe$', 'vvp.exe'
if (-not (Test-Path $vvpPath)) {
    $vvpPath = 'C:\iverilog\bin\vvp.exe'
}

$compileArgs = @('-g2012', '-s', 'tpu_top_tb', '-o', 'sim.out') + $rtlFiles + $tbFiles

Write-Host "Compiling RTL with $iverilogPath ..."
& $iverilogPath @compileArgs

if ($LASTEXITCODE -ne 0) {
    Write-Error "Simulation compile failed."
    exit $LASTEXITCODE
}

Write-Host "Running simulation with $vvpPath ..."
& $vvpPath '.\sim.out'

exit $LASTEXITCODE
