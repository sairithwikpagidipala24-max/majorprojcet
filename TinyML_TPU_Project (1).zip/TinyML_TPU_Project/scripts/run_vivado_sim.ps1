$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$vivadoPath = $null

$patterns = @(
    'vivado.exe',
    "$env:ProgramFiles\Xilinx\Vivado\*\bin\vivado.bat",
    "$env:ProgramFiles(x86)\Xilinx\Vivado\*\bin\vivado.bat",
    "$env:LOCALAPPDATA\Programs\Xilinx\Vivado\*\bin\vivado.bat",
    'D:\vivado\*\Vivado\bin\vivado.bat',
    'D:\Xilinx\Vivado\*\bin\vivado.bat',
    'D:\Vivado\*\bin\vivado.bat'
)

foreach ($pattern in $patterns) {
    $matches = Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue
    if ($matches) {
        $vivadoPath = $matches[0].FullName
        break
    }
}

if (-not $vivadoPath) {
    $cmd = Get-Command vivado -ErrorAction SilentlyContinue
    if ($cmd) {
        $vivadoPath = $cmd.Source
    }
}

if (-not $vivadoPath) {
    Write-Error "Vivado not found. Install Xilinx Vivado and add it to PATH before running the Vivado simulation flow."
    exit 1
}

Write-Host "Launching Vivado simulation with: $vivadoPath"
& $vivadoPath -mode batch -source "$scriptDir\run_vivado_sim.tcl"
exit $LASTEXITCODE
