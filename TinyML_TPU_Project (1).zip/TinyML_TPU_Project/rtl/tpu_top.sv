module tpu_top #(
    parameter integer N     = 4,
    parameter integer WIDTH = 16
) (
    input  logic clk,
    input  logic rst_n,
    input  logic start,
    input  logic [1:0] precision_mode,
    input  logic [N-1:0] active_rows,
    input  logic [N-1:0] active_cols,
    input  logic signed [WIDTH-1:0] a_vec [0:N-1],
    input  logic signed [WIDTH-1:0] b_vec [0:N-1],
    output logic done,
    output logic signed [(2*WIDTH + 8)-1:0] result0,
    output logic signed [(2*WIDTH + 8)-1:0] result1,
    output logic signed [(2*WIDTH + 8)-1:0] result2,
    output logic signed [(2*WIDTH + 8)-1:0] result3
);

    logic [1:0] precision_sel;
    logic       scale_enable;
    logic       clock_gate;
    logic signed [(2*WIDTH + 8)-1:0] row_sum [0:N-1];
    logic signed [(2*WIDTH + 8)-1:0] scaled_row_sum [0:N-1];
    logic signed [(2*WIDTH + 8)-1:0] result_reg [0:N-1];

    precision_controller ctrl (
        .mode(precision_mode),
        .precision_sel(precision_sel),
        .scale_enable(scale_enable),
        .clock_gate(clock_gate)
    );

    always_comb begin
        for (int i = 0; i < N; i++) begin
            row_sum[i] = '0;
            if (rst_n && active_rows[i]) begin
                for (int j = 0; j < N; j++) begin
                    if (active_cols[j]) begin
                        row_sum[i] = row_sum[i] + (a_vec[i] * b_vec[j]);
                    end
                end
            end

            scaled_row_sum[i] = row_sum[i];
            if (scale_enable && precision_mode == 2'b10) begin
                scaled_row_sum[i] = row_sum[i] >> 1;
            end
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (int i = 0; i < N; i++) begin
                result_reg[i] <= '0;
            end
            done <= 1'b0;
        end else if (start) begin
            for (int i = 0; i < N; i++) begin
                result_reg[i] <= scaled_row_sum[i];
            end
            done <= 1'b1;
        end else begin
            done <= 1'b0;
        end
    end

    always_comb begin
        result0 = result_reg[0];
        result1 = result_reg[1];
        result2 = result_reg[2];
        result3 = result_reg[3];
    end

endmodule
