module configurable_tpu_core #(
    parameter integer N     = 4,
    parameter integer WIDTH = 16
) (
    input  logic clk,
    input  logic rst_n,
    input  logic start,
    input  logic [N-1:0] active_rows,
    input  logic [N-1:0] active_cols,
    input  logic [1:0] precision_mode,
    input  logic signed [WIDTH-1:0] a_matrix [0:N-1],
    input  logic signed [WIDTH-1:0] b_matrix [0:N-1],
    output logic done,
    output logic signed [2*WIDTH+7:0] out_vector [0:N-1]
);

    logic [1:0] precision_sel;
    logic       scale_enable;
    logic       clock_gate;
    logic signed [2*WIDTH-1:0] accum [0:N-1];

    precision_controller ctrl (
        .mode(precision_mode),
        .precision_sel(precision_sel),
        .scale_enable(scale_enable),
        .clock_gate(clock_gate)
    );

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            done <= 1'b0;
            for (int i = 0; i < N; i++) begin
                accum[i] <= '0;
                out_vector[i] <= '0;
            end
        end else if (start) begin
            done <= 1'b1;
            for (int i = 0; i < N; i++) begin
                accum[i] <= '0;
                out_vector[i] <= '0;
            end

            for (int i = 0; i < N; i++) begin
                if (active_rows[i]) begin
                    for (int j = 0; j < N; j++) begin
                        if (active_cols[j]) begin
                            accum[i] <= accum[i] + (a_matrix[i] * b_matrix[j]);
                        end
                    end
                end
            end

            for (int i = 0; i < N; i++) begin
                out_vector[i] <= accum[i] + { {8{scale_enable}}, precision_sel };
            end
        end else begin
            done <= 1'b0;
        end
    end

endmodule
