module adaptive_systolic_array #(
    parameter integer N     = 4,
    parameter integer WIDTH = 16
) (
    input  logic clk,
    input  logic rst_n,
    input  logic en,
    input  logic [N-1:0] active_rows,
    input  logic [N-1:0] active_cols,
    input  logic signed [WIDTH-1:0] a_vec [0:N-1],
    input  logic signed [WIDTH-1:0] b_vec [0:N-1],
    output logic signed [(2*WIDTH + 8)-1:0] result [0:N-1]
);

    logic signed [2*WIDTH-1:0] accum [0:N-1];
    logic signed [2*WIDTH-1:0] next_accum [0:N-1];

    always_comb begin
        for (int i = 0; i < N; i++) begin
            next_accum[i] = '0;
            if (active_rows[i]) begin
                for (int j = 0; j < N; j++) begin
                    if (active_cols[j]) begin
                        next_accum[i] = next_accum[i] + (a_vec[i] * b_vec[j]);
                    end
                end
            end
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (int i = 0; i < N; i++) begin
                accum[i] <= '0;
                result[i] <= '0;
            end
        end else if (en) begin
            for (int i = 0; i < N; i++) begin
                accum[i] <= next_accum[i];
                result[i] <= next_accum[i];
            end
        end
    end

endmodule
