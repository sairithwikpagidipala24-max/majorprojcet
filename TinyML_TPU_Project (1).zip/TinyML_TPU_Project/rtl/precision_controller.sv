module precision_controller (
    input  logic [1:0] mode,
    output logic [1:0] precision_sel,
    output logic       scale_enable,
    output logic       clock_gate
);

    always_comb begin
        case (mode)
            2'b00: begin
                precision_sel = 2'b00; // 8-bit mode
                scale_enable = 1'b1;
                clock_gate   = 1'b0;
            end
            2'b01: begin
                precision_sel = 2'b01; // 16-bit mode
                scale_enable = 1'b1;
                clock_gate   = 1'b0;
            end
            2'b10: begin
                precision_sel = 2'b10; // mixed precision
                scale_enable = 1'b1;
                clock_gate   = 1'b1;
            end
            default: begin
                precision_sel = 2'b11; // safe fallback
                scale_enable = 1'b0;
                clock_gate   = 1'b0;
            end
        endcase
    end

endmodule
