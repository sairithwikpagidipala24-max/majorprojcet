module pe #(
    parameter integer WIDTH = 16
) (
    input  logic clk,
    input  logic rst_n,
    input  logic en,
    input  logic signed [WIDTH-1:0] a_in,
    input  logic signed [WIDTH-1:0] b_in,
    input  logic signed [2*WIDTH-1:0] acc_in,
    output logic signed [WIDTH-1:0] a_out,
    output logic signed [WIDTH-1:0] b_out,
    output logic signed [2*WIDTH-1:0] acc_out
);

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            a_out   <= '0;
            b_out   <= '0;
            acc_out <= '0;
        end else if (en) begin
            a_out   <= a_in;
            b_out   <= b_in;
            acc_out <= acc_in + (a_in * b_in);
        end
    end

endmodule
