module tpu_top_tb;

    localparam integer N     = 4;
    localparam integer WIDTH = 16;

    logic clk;
    logic rst_n;
    logic start;
    logic [1:0] precision_mode;
    logic [N-1:0] active_rows;
    logic [N-1:0] active_cols;
    logic signed [WIDTH-1:0] a_vec [0:N-1];
    logic signed [WIDTH-1:0] b_vec [0:N-1];
    logic done;
    logic signed [(2*WIDTH + 8)-1:0] result0;
    logic signed [(2*WIDTH + 8)-1:0] result1;
    logic signed [(2*WIDTH + 8)-1:0] result2;
    logic signed [(2*WIDTH + 8)-1:0] result3;

    tpu_top #(.N(N), .WIDTH(WIDTH)) dut (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .precision_mode(precision_mode),
        .active_rows(active_rows),
        .active_cols(active_cols),
        .a_vec(a_vec),
        .b_vec(b_vec),
        .done(done),
        .result0(result0),
        .result1(result1),
        .result2(result2),
        .result3(result3)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rst_n = 0;
        start = 0;
        precision_mode = 2'b01;
        active_rows = 4'b1100;
        active_cols = 4'b0011;

        a_vec[0] = 16'd2;
        a_vec[1] = 16'd3;
        a_vec[2] = 16'd1;
        a_vec[3] = 16'd4;

        b_vec[0] = 16'd5;
        b_vec[1] = 16'd6;
        b_vec[2] = 16'd7;
        b_vec[3] = 16'd8;

        #12 rst_n = 1;
        #10 start = 1;
        #10 start = 0;

        repeat (4) @(posedge clk);

        $display("Result[0] = %0d", result0);
        $display("Result[1] = %0d", result1);
        $display("Result[2] = %0d", result2);
        $display("Result[3] = %0d", result3);

        if (result0 !== 0 || result1 !== 0 || result2 !== 11 || result3 !== 44) begin
            $display("FAIL: expected row2=11, row3=44, other rows=0");
            $fatal;
        end

        #20;
        active_rows = 4'b1111;
        active_cols = 4'b1111;
        a_vec[0] = 16'd2;
        a_vec[1] = 16'd3;
        a_vec[2] = 16'd1;
        a_vec[3] = 16'd4;
        b_vec[0] = 16'd5;
        b_vec[1] = 16'd6;
        b_vec[2] = 16'd7;
        b_vec[3] = 16'd8;

        #10 start = 1;
        #10 start = 0;
        repeat (4) @(posedge clk);

        $display("Case2 Result[0] = %0d", result0);
        $display("Case2 Result[1] = %0d", result1);
        $display("Case2 Result[2] = %0d", result2);
        $display("Case2 Result[3] = %0d", result3);

        if (result0 !== 52 || result1 !== 78 || result2 !== 26 || result3 !== 104) begin
            $display("FAIL: expected full-mask outputs 52,78,26,104");
            $fatal;
        end

        #20;
        active_rows = 4'b1111;
        active_cols = 4'b1111;
        a_vec[0] = -16'd2;
        a_vec[1] = 16'd3;
        a_vec[2] = -16'd1;
        a_vec[3] = 16'd4;
        b_vec[0] = 16'd5;
        b_vec[1] = -16'd6;
        b_vec[2] = 16'd7;
        b_vec[3] = -16'd8;

        #10 start = 1;
        #10 start = 0;
        repeat (4) @(posedge clk);

        $display("Case3 Result[0] = %0d", result0);
        $display("Case3 Result[1] = %0d", result1);
        $display("Case3 Result[2] = %0d", result2);
        $display("Case3 Result[3] = %0d", result3);

        if (result0 !== 4 || result1 !== -6 || result2 !== 2 || result3 !== -8) begin
            $display("FAIL: expected signed full-mask outputs 4,-6,2,-8");
            $fatal;
        end

        #20;
        precision_mode = 2'b10;
        active_rows = 4'b1111;
        active_cols = 4'b1111;
        a_vec[0] = 16'd2;
        a_vec[1] = 16'd3;
        a_vec[2] = 16'd1;
        a_vec[3] = 16'd4;
        b_vec[0] = 16'd5;
        b_vec[1] = 16'd6;
        b_vec[2] = 16'd7;
        b_vec[3] = 16'd8;

        #10 start = 1;
        #10 start = 0;
        repeat (4) @(posedge clk);

        $display("Case4 Result[0] = %0d", result0);
        $display("Case4 Result[1] = %0d", result1);
        $display("Case4 Result[2] = %0d", result2);
        $display("Case4 Result[3] = %0d", result3);

        if (result0 !== 26 || result1 !== 39 || result2 !== 13 || result3 !== 52) begin
            $display("FAIL: expected mixed-precision full-mask outputs 26,39,13,52");
            $fatal;
        end

        $display("PASS: adaptive systolic array produced expected MAC outputs across four validation cases");
        $finish;
    end

endmodule
