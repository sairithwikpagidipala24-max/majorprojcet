set_param project.enableReportConfiguration 0
load_feature core
current_fileset
xsim {tpu_top_tb_behav} -wdb {tpu_top_tb_viewer.wdb} -autoloadwcfg -tclbatch {D:/projectworld/6/TinyML_TPU_Project/scripts/open_xsim_waveforms.tcl} -onfinish stop
