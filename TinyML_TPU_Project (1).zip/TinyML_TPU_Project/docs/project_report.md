# Configurable TinyML TPU with Adaptive Systolic Array and Runtime Precision Scaling

## 1. Overview

This project proposes a TPU-inspired accelerator tailored for TinyML workloads. The design focuses on reducing processing-element underutilization by adapting the active systolic-array region according to the current workload and precision requirement.

## 2. Motivation

TinyML workloads are often small but highly repetitive. Fixed-size accelerators waste hardware resources when the required computation size is much smaller than the available array. In such cases, switching off unnecessary PEs and reducing precision dynamically can significantly improve energy efficiency.

## 3. Design goals

- Optimize PE utilization
- Reduce power consumption in small workloads
- Support runtime precision scaling
- Improve throughput-energy tradeoff for edge inference
- Keep the design synthesizable using SystemVerilog

## 4. Core architecture

The complete architecture contains the following blocks:

- Input buffers for activations and weights
- Configurable PE array
- Adaptive row/column control logic
- Precision controller
- Accumulator and output buffer
- Top-level TPU control FSM

## 5. Systolic execution model

The PE array executes matrix-style multiply-and-accumulate operations in a pipelined manner. The active region of the array is selected by row and column masks. When a workload is small, only the required subset of PEs is enabled.

## 6. Runtime precision scaling

Precision mode may be selected at runtime according to workload complexity and accuracy requirement. For example:

- 8-bit mode: maximum throughput and lower energy
- 16-bit mode: higher accuracy for more sensitive tasks
- mixed precision: selective high-precision compute for critical paths

## 7. Expected benefits

Compared to a fixed-size systolic array, the adaptive design is expected to show:

- higher PE utilization
- reduced unnecessary switching activity
- better energy efficiency
- lower idle resource overhead

## 8. Verification strategy

The design is verified through:

- functional simulation
- edge-case workload testing
- adaptive mask toggling
- precision mode transition checks
- output integrity comparison against reference MAC computation

## 9. Tools

- SystemVerilog
- Xilinx Vivado
- iverilog (optional local simulation)

## 10. Verified implementation status

The current RTL baseline was validated successfully in the Windows environment with Icarus Verilog. The testbench checks multiple activation patterns and confirms correct MAC behavior for active processing rows, including signed mixed-sign values.

Observed outputs from the final Windows proof run:

- Case 1: 0, 0, 11, 44
- Case 2: 52, 78, 26, 104
- Case 3: 4, -6, 2, -8
- Result: PASS
- Exit code: 0

The Python benchmark was also updated to mirror the hardware’s row/column-masked accumulation semantics and passed its validation suite across the same cases.

## 11. Conclusion

This project is a relevant and practical accelerator-design effort for embedded AI. It combines the principles of a systolic-array accelerator with adaptive reconfiguration and runtime precision scaling, which are valuable for future TinyML deployments.
