# Configurable TinyML TPU with Adaptive Systolic Array

This project is a working hardware-design scaffold inspired by the major project titled:

"Design a Configurable TinyML TPU with Adaptive Systolic Array and Runtime Precision Scaling"

It implements a minimal, synthesizable RTL baseline for:

- configurable active processing elements
- adaptive array activation using row/column masks
- runtime precision mode selection
- testbench-driven verification
- Vivado/iverilog-friendly structure

## Project goals

- Design a TPU-inspired accelerator for TinyML workloads
- Enable dynamic activation of processing elements based on workload size
- Support runtime precision scaling for energy/performance trade-offs
- Validate functionality via simulation

## Directory structure

- `rtl/` - SystemVerilog RTL modules
- `tb/` - simulation testbench
- `scripts/` - helper scripts
- `Makefile` - simple build entry point

## High-level architecture

- `pe.sv` : processing element unit implementing MAC behavior
- `adaptive_systolic_array.sv` : adaptive array logic using active row/column masks
- `tpu_top.sv` : integration layer for the TPU controller and array
- `tpu_top_tb.sv` : basic functional verification

## Simulation

On Linux/macOS:

```bash
make sim
```

On Windows with Icarus Verilog:

```powershell
.\scripts\run_sim.ps1
```

On Windows with Vivado (if the Xilinx toolchain is installed):

```powershell
.\scripts\run_vivado_sim.ps1
```

## Typical Vivado usage

1. Add `rtl/*.sv` to a new Vivado project
2. Add `tb/tpu_top_tb.sv` as a simulation source
3. Compile and run behavioral simulation
4. Observe output values and verify matrix-like MAC behavior

The project includes a ready-to-use TCL script in `scripts/run_vivado_sim.tcl` to create a local Vivado project and run the behavioral simulation automatically.

## Verified status

The RTL and testbench were validated on Windows using Icarus Verilog.

```powershell
Set-Location 'D:\projectworld\6\TinyML_TPU_Project'; powershell -ExecutionPolicy Bypass -File .\scripts\run_sim.ps1; Write-Host "SCRIPT_EXIT:$LASTEXITCODE"
```

Fresh output from the extended proof run:

```text
Result[0] = 0
Result[1] = 0
Result[2] = 11
Result[3] = 44
Case2 Result[0] = 52
Case2 Result[1] = 78
Case2 Result[2] = 26
Case2 Result[3] = 104
Case3 Result[0] = 4
Case3 Result[1] = -6
Case3 Result[2] = 2
Case3 Result[3] = -8
PASS: adaptive systolic array produced expected MAC outputs across three validation cases
SCRIPT_EXIT:0
```

The Python benchmark was also extended with a systematic mask sweep and randomized regression pass to exercise active row/column combinations beyond the fixed proof vectors.

## Notes

This is a strong engineering starter project, not a fully optimized ASIC implementation. It is meant to provide a credible RTL base for a major project, viva/demo, or further expansion.
